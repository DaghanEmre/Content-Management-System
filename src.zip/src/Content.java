import java.io.PrintWriter;


public abstract class Content {
	
	private int content_ID;
	private String file_Name;
	private String mime_Type;
	private int request_By_User_Id;
	
	public int getContent_ID() {
		return content_ID;
	}
	
	public void setContent_ID(int content_ID) {
		this.content_ID = content_ID;
	}
	
	public String getFile_Name() {
		return file_Name;
	}
	
	public void setFile_Name(String file_Name) {
		this.file_Name = file_Name;
	}
	
	public String getMime_Type() {
		return mime_Type;
	}
	
	public void setMime_Type(String mime_Type) {
		this.mime_Type = mime_Type;
	}
	
	public int getRequest_By_User_Id() {
		return request_By_User_Id;
	}
	
	public void setRequest_By_User_Id(int request_By_User_Id) {
		this.request_By_User_Id = request_By_User_Id;
	}

	Content() {
		super();
	}

	
	public Content(int content_ID, String file_Name, String mime_Type,
			int request_By_User_Id) {
		super();
		this.content_ID = content_ID;
		this.file_Name = file_Name;
		this.mime_Type = mime_Type;
		this.request_By_User_Id = request_By_User_Id;
	}
	
	public abstract void toString_Result(PrintWriter resultFile);
	
	public abstract void toString_Log(PrintWriter logFile);
	
}
