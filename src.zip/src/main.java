import java.util.Scanner; 
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;


public class main {

	public static void main(String[] args) 
	{
		CMS_LinkedList cms_LinkedList = new CMS_LinkedList();
		CMS_LinkedList userList = new CMS_LinkedList();
		CMS_LinkedList roleList = new CMS_LinkedList();
		
		
		FileParser.parseFile("D:\\input.inp", "D:\\result.out","D:\\log.out", cms_LinkedList, 
				userList, roleList);
		
	}
	
	public static void functionSelection(PrintWriter writer_result, PrintWriter writer_log,
			String line, CMS_LinkedList cms_LinkedList, 
			CMS_LinkedList userList, CMS_LinkedList roleList){
		
		
		String[] lineArray = line.split(",");
		
		String[] token =  lineArray[0].split(" "); 
		
		String[] token1 = line.split(" ");
		
		if(token[0].equals("PUT")){
		
				String command = token[1];
				
				if(command.equals("ROLE")){
					
					addRole(writer_result, writer_log, lineArray, roleList);;
				
				}else if (command.equals("USER")){
					
					addUser(writer_result, writer_log, lineArray, userList);
				
				}else if (command.equals("CONTENT")){
				
						String type_content = lineArray[2];
						
						if((type_content.equals("TXT")) || (type_content.equals("PDF"))){
							
							addDocument(writer_result, writer_log, lineArray, cms_LinkedList);
						
						}else if((type_content.equals("AVI")) || (type_content.equals("MP4"))){
							
							addVideo(writer_result, writer_log, lineArray, cms_LinkedList);
						
						}else if((type_content.equals("PNG")) || (type_content.equals("JPG"))){
							
							addImage(writer_result, writer_log, lineArray, cms_LinkedList);
						}
						
				} 	
		
		} else if (token1[0].equals("GET")){
		
			
		} else if (token1[0].equals("LIST")){
			
			if(token1[2].equals("SIZE")){
				
				
			} else if(token1[2].equals("TYPE")){
				
				
			}
		
		} else
			writer_result.println("Command:invalid command!");
			writer_result.println("Command Failed");
			writer_log.println("COMMAND FAILED!");
	}
	
	
	public static void addRole(PrintWriter resultFile, PrintWriter logFile, 
			String[] lineArray, CMS_LinkedList roleList){
		
		String[] piece = lineArray[0].split(" ");
		int role_ID = Integer.parseInt(piece[2]);
		String role_Name = lineArray[1];
		String authority = lineArray[4];
		
		Role role_elem = new Role(role_ID, role_Name, authority);
		roleList.insert(role_elem);
		
		role_elem.toString_Result_Role(resultFile);
		role_elem.toString_Log_Role(logFile);
		
	}
	
	public static void addUser(PrintWriter resultFile, PrintWriter logFile, 
			String[] lineArray, CMS_LinkedList userList){
		int cont = userList.size();
		
		String[] piece = lineArray[0].split(" ");
		int user_ID = Integer.parseInt(piece[2]);
		String user_fullname = lineArray[1];
		int authority_User = Integer.parseInt(lineArray[2]);
		
		//Making an Object
		User user_elem = new User(user_ID, user_fullname, authority_User);
		userList.insert(user_elem);
		
		user_elem.toString_Result_User(resultFile);
		user_elem.toString_Log_User(logFile);
		
	}
	
	public static void addImage(PrintWriter resultFile, PrintWriter logFile, 
			String[] lineArray, CMS_LinkedList cms_LinkedList){
	
		String[] piece = lineArray[0].split(" ");
		int content_ID = Integer.parseInt(piece[2]);
		String file_Name = lineArray[1];
		String mime_Type = lineArray[2];
		String[] piece2 = lineArray[3].split(" ");
		int request_By_User_Id = Integer.parseInt(piece2[2]);
		
		//GETT�NG HEADER-SUMMARY
		int number_LastElem = piece2[0].lastIndexOf("}");   //Finding the Last Element's index of string  
		String header_Summary = piece2[0].substring(1, number_LastElem - 1); //Parsing the parentheses from the string
		String[] piece3 = header_Summary.split("x");
		int resX = Integer.parseInt(piece3[0]);       //Getting resX
		int resY = Integer.parseInt(piece3[1]);		  //Getting resY
		
		Image image_elem = new Image(content_ID, file_Name, mime_Type, request_By_User_Id, resX, resY);
		cms_LinkedList.insert(image_elem);
		
		image_elem.toString_Result(resultFile);
		image_elem.toString_Log(logFile);
		
	}

	
	public static void addDocument(PrintWriter resultFile, PrintWriter logFile, 
			String[] lineArray, CMS_LinkedList cms_LinkedList){
		
		String[] piece = lineArray[0].split(" ");
		int content_ID = Integer.parseInt(piece[2]);
		String file_Name = lineArray[1];
		String mime_Type = lineArray[2];
		String[] piece2 = lineArray[3].split(" ");
		int request_By_User_Id = Integer.parseInt(piece2[2]);
		
		//GETT�NG HEADER-SUMMARY
		int number_LastElem = piece2[0].lastIndexOf("}");   //Finding the Last Element's index of string  
		String header_Summary = piece2[0].substring(1, number_LastElem - 1); //Parsing the parentheses from the string
		int number_of_characters = Integer.parseInt(header_Summary);
		
		Document document_elem = new Document(content_ID, file_Name, mime_Type, request_By_User_Id, number_of_characters);
		cms_LinkedList.insert(document_elem);
		
		document_elem.toString_Result(resultFile);
		document_elem.toString_Log(logFile);
		
	}
	
	public static void addVideo(PrintWriter resultFile, PrintWriter logFile, 
			String[] lineArray, CMS_LinkedList cms_LinkedList){
		
		String[] piece = lineArray[0].split(" ");
		int content_ID = Integer.parseInt(piece[2]);
		String file_Name = lineArray[1];
		String mime_Type = lineArray[2];
		String[] piece2 = lineArray[3].split(" ");
		int request_By_User_Id = Integer.parseInt(piece2[2]);
		
		//GETT�NG HEADER-SUMMARY
		int number_LastElem = piece2[0].lastIndexOf("}");   //Finding the Last Element's index of string  
		String header_Summary = piece2[0].substring(1, number_LastElem - 1); //Parsing the parentheses from the string
		String[] piece3 = header_Summary.split(",");
		int fps_Value = Integer.parseInt(piece3[0]);
		int lenght = Integer.parseInt(piece3[2]);
		String[] piece4 = piece3[1].split("x");
		int resX = Integer.parseInt(piece4[0]);
		int resY = Integer.parseInt(piece4[1]);
		
		Video video_elem = new Video(content_ID, file_Name, mime_Type, request_By_User_Id, fps_Value, resX, resY, lenght);
		cms_LinkedList.insert(video_elem);
		
		video_elem.toString_Result(resultFile);
		video_elem.toString_Log(logFile);
	}
	
}
