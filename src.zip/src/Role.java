import java.io.PrintWriter;


public class Role {
	
	private int role_ID;
	private String role_Name;
	private String authority;
	
	public int getRole_ID() {
		return role_ID;
	}
	
	public void setRole_ID(int role_ID) {
		this.role_ID = role_ID;
	}
	
	public String getRole_Name() {
		return role_Name;
	}
	
	public void setRole_Name(String role_Name) {
		this.role_Name = role_Name;
	}
	
	public String getAuthority() {
		return authority;
	}
	
	public void setAuthority(String authority) {
		this.authority = authority;
	}

	public Role(int role_ID, String role_Name, String authority) {
		super();
		this.role_ID = role_ID;
		this.role_Name = role_Name;
		this.authority = authority;
	}
	
	public void toString_Result_Role(PrintWriter resultFile){
		resultFile.println("Command:" + "PUT ROLE " + this.role_ID
				+ "," + this.role_Name + "," + this.authority );
		resultFile.println(this.role_Name + " role is added");
	}
	
	public void toString_Log_Role(PrintWriter logFile){
		logFile.println("ROLE ADDED");
	}
	

}
