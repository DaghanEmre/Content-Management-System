import java.io.PrintWriter;


public class User {
	
	private int user_ID;
	private String user_fullname;
	private int authority_User;
	
	public int getAuthority_User() {
		return authority_User;
	}

	public void setAuthority_User(int authority_User) {
		this.authority_User = authority_User;
	}

	public int getUser_ID() {
		return user_ID;
	}
	
	public void setUser_ID(int user_ID) {
		this.user_ID = user_ID;
	}
	
	public String getUser_fullname() {
		return user_fullname;
	}
	
	public void setUser_fullname(String user_fullname) {
		this.user_fullname = user_fullname;
	}

	public User(int user_ID, String user_fullname, int authority_User) {
		super();
		this.user_ID = user_ID;
		this.user_fullname = user_fullname;
		this.authority_User = authority_User;
	}
	
	public void toString_Result_User(PrintWriter resultFile){
		resultFile.println("Command:" + "PUT USER " + this.user_ID
				+ "," + this.user_fullname + "," + this.authority_User);
		resultFile.println("A(n) ");
	}
	
	public void toString_Log_User(PrintWriter logFile){
		logFile.println("USER ADDED");
	}
	

}
