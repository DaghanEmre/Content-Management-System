import java.io.PrintWriter;


public class Document extends Content {
	
	private int number_of_characters;

	public int getNumber_of_characters() {
		return number_of_characters;
	}

	public void setNumber_of_characters(int number_of_characters) {
		this.number_of_characters = number_of_characters;
	}

	public Document(int content_ID, String file_Name, String mime_Type,
			int request_By_User_Id, int number_of_characters) {
		super(content_ID, file_Name, mime_Type, request_By_User_Id);
		this.number_of_characters = number_of_characters;
	}
	
	@Override
	public void toString_Result(PrintWriter resultFile){
		resultFile.println("Command:" + "PUT CONTENT " + super.getContent_ID()
				+ "," + super.getFile_Name() + "," + super.getMime_Type()
				+ ",{" + this.number_of_characters + "} REQUESTED_BY " 
				+ super.getRequest_By_User_Id());
		resultFile.println();
	}
	
	@Override
	public void toString_Log(PrintWriter logFile){
		logFile.println("A DOCUMENT ADDED");
	}
	

}
