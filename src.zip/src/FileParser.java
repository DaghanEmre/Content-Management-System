
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;


public class FileParser {
	
	public static void parseFile(String inputFile, String resultFile,
			String logFile,  CMS_LinkedList cms_LinkedList,
			 CMS_LinkedList userList, CMS_LinkedList roleList){
		
		Scanner scanner = null;
		PrintWriter writer_result = null;
		PrintWriter writer_log = null;
		
		String line = null;
		
		try{
			scanner = new Scanner(new File(inputFile));
			writer_result = new PrintWriter(new File(resultFile));
			writer_log = new PrintWriter(new File(logFile));
			
			while (scanner.hasNext()) {
				 
				line = scanner.nextLine();
				
				main.functionSelection(writer_result, writer_log, line, 
						cms_LinkedList, userList, roleList);
				
			}
		
		} catch (FileNotFoundException e){
			e.printStackTrace();
		} finally {
			scanner.close();
			writer_result.close();
			writer_log.close();
		}
		return;
		
	}

}


