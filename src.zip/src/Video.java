import java.io.PrintWriter;


public class Video extends Content {
	
	private int fps_Value;
	private int resX;
	private int resY;
	private int lenght;
	
	public int getFps_Value() {
		return fps_Value;
	}

	public void setFps_Value(int fps_Value) {
		this.fps_Value = fps_Value;
	}

	public int getResX() {
		return resX;
	}
	
	public void setResX(int resX) {
		this.resX = resX;
	}
	
	public int getResY() {
		return resY;
	}
	
	public void setResY(int resY) {
		this.resY = resY;
	}
	
	public int getLenght() {
		return lenght;
	}
	
	public void setLenght(int lenght) {
		this.lenght = lenght;
	}

	public Video(int content_ID, String file_Name, String mime_Type,
			int request_By_User_Id, int fps_Value, int resX, int resY,
			int lenght) {
		super(content_ID, file_Name, mime_Type, request_By_User_Id);
		this.fps_Value = fps_Value;
		this.resX = resX;
		this.resY = resY;
		this.lenght = lenght;
	}
	
	@Override
	public void toString_Result(PrintWriter resultFile){
		resultFile.println("Command:" + "PUT CONTENT " + super.getContent_ID()
				+ "," + super.getFile_Name() + "," + super.getMime_Type()
				+ ",{" + this.fps_Value + "," +this.resX + "x" + this.resY + "," +this.lenght + "} REQUESTED_BY " 
				+ super.getRequest_By_User_Id());
		resultFile.println();
	}
	
	@Override
	public void toString_Log(PrintWriter logFile){
		logFile.println("A VIDEO ADDED");
	}
	
	
	

}
