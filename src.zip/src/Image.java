import java.io.PrintWriter;


public class Image extends Content {
	
	private int resX;
	private int resY;
	
	public int getResX() {
		return resX;
	}
	
	public void setResX(int resX) {
		this.resX = resX;
	}
	
	public int getResY() {
		return resY;
	}
	
	public void setResY(int resY) {
		this.resY = resY;
	}

	public Image(int content_ID, String file_Name, String mime_Type,
			int request_By_User_Id, int resX, int resY) {
		super(content_ID, file_Name, mime_Type, request_By_User_Id);
		this.resX = resX;
		this.resY = resY;
	}
	
	@Override
	public void toString_Result(PrintWriter resultFile){
		resultFile.println("Command:" + "PUT CONTENT " + super.getContent_ID()
				+ "," + super.getFile_Name() + "," + super.getMime_Type()
				+ ",{" + this.resX + "x" + this.resY + "} REQUESTED_BY " 
				+ super.getRequest_By_User_Id());
		resultFile.println();
	}
	
	@Override
	public void toString_Log(PrintWriter logFile){
		logFile.println("AN IMAGE ADDED");
	}
	
}
