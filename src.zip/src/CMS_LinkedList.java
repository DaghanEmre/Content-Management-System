public class CMS_LinkedList {
	
	
	//reference to the head node
	private int m_size;
	private Node m_head;

	// default constructor initializes LinkedList
	public CMS_LinkedList()
	{
			m_head = new Node(null);
			m_size = 0;
	}


	// function that add element to the position which is indicated by position parameter in the list 
	// if there is an error when inserting content, return false, otherwise true.
	public boolean insert(Object m_data, int position)
	{
		Node CMS_Temp = new Node((Content) m_data);
		Node CMS_Current = m_head;
		
		for(int i = 1; i < position && CMS_Current.getNext() != null; i++)
		{
			CMS_Current =  CMS_Current.getNext();
		}
		
		CMS_Temp.setNext(CMS_Current.getNext());							//set the new node's next-node reference to this node' s next-node reference
		
		CMS_Current.setNext(CMS_Temp);										//set this node's next-node reference to the new node
		
		
		if(CMS_Current.getNext() == null)
			return false;
		
		else
		{
			m_size++; //increasing the number of elements variable
			return true;
		}
	}
	
	
	
	// function that add element to the position which is at the end of the list
	public boolean insert(Object m_data)
	{
		Node CMS_Temp = new Node((Content) m_data);
		Node CMS_Current = m_head;
		
		while(CMS_Current.getNext() != null)
		{
			CMS_Current =  CMS_Current.getNext();
		}
		
		CMS_Temp.setNext(CMS_Current.getNext());						//set the the last node's next-node reference to new node next-node reference
		
		CMS_Current.setNext(CMS_Temp);									//set the the last node's next-node reference to new node
		
		if(CMS_Current.getNext() == null)
			return false;
		
		else
		{
			m_size++; //increasing the number of elements variable
			return true;
		}
		
	}
	
	
	
	
	// function that removes element (content parameter) from the list 
	// if there is an error when removing content, return false, otherwise true.
	public boolean remove( int position )
	{
		// if the position is out of range, exit
		if (position < 1 || position > size())
            return false;
		
		Node CMS_Current = m_head;
		
		for (int i = 1; i < position; i++) {
	           if (CMS_Current.getNext() == null)
	               return false;
	    CMS_Current = CMS_Current.getNext();
		}
		
		CMS_Current.setNext(CMS_Current.getNext().getNext());
		
		m_size--;
		return true;
	}

	
	
	public int size()
	{
			return m_size;
	}
	
	
	public Object get(int position)          //returns the element at the specified position in this list
	{
		if(position <= 0)
			return null;
		
		Node CMS_Current = m_head.getNext();
		for(int i = 1;i < position; i++){
			if(CMS_Current.getNext() == null)
				return null;
			CMS_Current = CMS_Current.getNext();
		}
		
		return CMS_Current.getData();
	}
	
	
	public String toString_cms()
	{
		Node CMS_Current = m_head.getNext();
		String output = "";
		while(CMS_Current != null){
			output += "[" + CMS_Current.getData().toString() + "]";
			CMS_Current = CMS_Current.getNext();
		}
		return output;
	}
	
	
	// inner class Node
	public class Node
	{
			private Object m_next;  //reference to the next node
			
			private Content m_data;  //data carried by this node
		
			//Node constructor
			public Node(Content dataValue)
			{
				m_next = null;
				m_data = dataValue;
			}
			
			
			//another Node constructor to specify the node to the po�nt
			public Node(Content dataValue, Content nextNode)
			{
				m_next = nextNode;
				m_data = dataValue;
			}

			
			// function that sets content of Content object
			public void setData(Content dataValue)
			{
				m_data = dataValue;
			}

			
			// function that sets next pointer of Content object
			public void setNext(Node nextNode)
			{
				m_next = nextNode;
			}
			
			public Content getData()
			{
				return m_data;
			}
			
			
			public Node getNext()
			{
				return (Node) m_next;
			}

	}
	
}
